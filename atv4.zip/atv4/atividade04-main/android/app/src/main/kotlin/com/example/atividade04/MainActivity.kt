package com.example.atividade04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
